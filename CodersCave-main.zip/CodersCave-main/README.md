This is my project1 in my internship at coders cave. 
It is a quote generator web application.
It is a simple application. 
I have used HTML, CSS, and JavaScript to build this web application. 
